"""
Author: Bui Hieu Tho
Date: 25/10/2021
Problem:Add a command to this chapter’s case study program that allows the user to
view the contents of a file in the current working directory. When the command
is selected, the program should display a list of filenames and a prompt for the
name of the file to be viewed. Be sure to include error recovery.
Solution:
    ....
"""