"""
Author: Bui Hieu Tho
Date: 25/10/2021
Problem:Write the code for a reducing that creates a single string from a list of strings named
words.
Solution:
words=['Programming ', 'in ', 'Python ', 'is ', 'fun!']
Output:
'Programming in Python is fun!'
    ....
"""