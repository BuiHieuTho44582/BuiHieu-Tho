"""
Author: Bui Hieu Tho
Date: 25/10/2021
Problem:Write the code for a mapping that generates a list of the absolute values of the numbers in a list named numbers.
Solution:
int_num = -25

float_num = -10.50

print("The absolute value of an integer number is:", abs(int_num))
print("The absolute value of a float number is:", abs(float_num))
    ....
"""