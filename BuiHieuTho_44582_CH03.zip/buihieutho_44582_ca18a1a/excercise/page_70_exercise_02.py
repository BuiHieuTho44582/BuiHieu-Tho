"""
Author: Bùi hiếu thọ
Date: 18/09/2021

Problem:  Write a loop that prints your name 100 times. Each output should begin on a
new line

Solution:

    ....
"""
for count in range(10):
    print("thọ")
