"""
Author: Bùi hiếu thọ
Date: 18/09/2021

Problem:   Assume that x refers to a number. Write a code segment that prints the number’s
absolute value without using Python’s abs function.

Solution:

    ....
"""
x = -8
print("Giá trị tuyệt đối",abs(x))
