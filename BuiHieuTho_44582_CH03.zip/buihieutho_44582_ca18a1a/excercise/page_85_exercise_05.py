"""
Author: Bùi hiếu thọ
Date: 18/09/2021

Problem:  Explain how to check for an invalid input number and prevent it being used in a
program. You may assume that the user enters a number.

Solution:
khi tính s hình tròn nếu bán kính bằng 0 thì không hợp lệ

    ....
"""


