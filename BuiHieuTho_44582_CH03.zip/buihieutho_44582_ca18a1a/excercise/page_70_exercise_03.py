"""
Author: Bùi hiếu thọ
Date: 18/09/2021

Problem:  Explain the role of the variable in the header of a for loop.

Solution:   Một vòng lặp có hai phần: một tiêu đề chỉ định lặp lại và một cơ thể được thực hiện một lần cho mỗi lần lặp lại.
 Tiêu đề thường tuyên bố một bộ đếm vòng lặp rõ ràng hoặc biến vòng lặp,
 cho phép cơ thể biết lần lặp nào đang được thực hiện. Các vòng lặp thường được sử dụng khi số lần lặp lại được biết
 trước khi vào vòng lặp.

    ....
"""
