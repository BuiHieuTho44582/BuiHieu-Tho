"""
Author: Bùi hiếu thọ
Date: 18/09/2021

Problem:  Describe the purpose of the break statement and the type of problem for which it is
well suited

Solution:
Câu lệnh ngắt rất hữu ích để ngăn chặn một vòng lặp


    ....
"""





