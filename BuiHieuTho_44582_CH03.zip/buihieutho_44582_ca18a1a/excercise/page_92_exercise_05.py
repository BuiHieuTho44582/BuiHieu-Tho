"""
Author: Bùi hiếu thọ
Date: 18/09/2021

Problem:  What is the maximum number of guesses necessary to guess correctly a given number between the numbers N and M?

Solution:
 Với một khoảng
  [n,m],  (n + m)/2 ở mỗi bước.

    ....
"""





