"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: Evaluate the following code at a shell prompt: print ("Your name is", name).
Then assign name an appropriate value, and evaluate the statement again
Solution:
    ....
"""
name = input("Put your name here: ") # đặt tên biến trước rồi sau đó mới khai báo biến name được
print ("Your name is", name)
