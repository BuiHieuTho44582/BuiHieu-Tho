"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: Open an IDLE window, and enter the program from Figure 1-7 that computes
the area of a rectangle. Load the program into the shell by pressing the F5 key,
and correct any errors that occur. Test the program with different inputs by
running it at least three times.
Solution:
    ....
"""
radius=float(input("Nhap ban kinh duong tron: "))
area=3.14*radius**2
print("Dien tich hinh tron la: ",area)
