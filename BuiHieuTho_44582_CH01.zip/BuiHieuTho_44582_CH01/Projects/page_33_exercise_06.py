"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: Write and test a program that computes the area of a circle. This program should
    request a number representing a radius as input from the user. It should use the formula
    3.14 * radius ** 2 to compute the area and then output this result suitably labeled
Solution:
    ....
"""
radius=float(input("Nhap ban kinh duong tron: "))
area=3.14*radius**2
print("Dien tich hinh tron la: ",area)
