"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: Open a Python shell, enter the following expressions, and observe the results
Solution:
    1. CPU
    2. Memory
    3. Input and output
    ....
"""
print("8")
print("8*2")
print("8**2")
print("8/12")
print("8//12")
print("8/0")


