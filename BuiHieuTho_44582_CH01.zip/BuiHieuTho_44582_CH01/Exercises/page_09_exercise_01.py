"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: List two examples of input devices and two examples of output devices.
Solution:
    - Input
    1. Scanner
    This device can scan images or text and convert it into a digital signal
    2. Mouse
    Using mouse we can directly click on the various icons present on the system and open up various files and programs
    - Output
    1.Monitor
    The device which displays all the icons, text, images, etc
    2.Printer
    A device which makes a copy of the pictorial or textual content,
    ....
"""
