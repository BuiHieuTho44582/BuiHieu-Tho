"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: Explain what goes on behind the scenes when your computer runs a Python
program
Solution:
    Whether you are running Python code as a script or interactively in a shell, the Python
    interpreter does a great deal of work to carry out the instructions in your program. This
    work can be broken into a series of steps
    ....
"""
