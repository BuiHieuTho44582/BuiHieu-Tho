"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: List four devices that use computers and describe the information that they process.
(Hint: Think of the inputs and outputs of the devices.)
Solution:
    1. Scanner
    This device can scan images or text and convert it into a digital signal
    2. Mouse
    Using mouse we can directly click on the various icons present on the system and open up various files and programs
    3. Keyboard
    A simple device comprising keys and each key denotes either an alphabet, number or number commands which can be given to a computer for various actions to be performed
    4. Microphone
    - It converts sound into an electrical signal
    - To record or reproduce a sound created using a microphone, it needs to be connected with an amplifier
    ....

"""
print("hello world")
