"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: Miranda has forgotten to complete an arithmetic expression before the end of a line
of code. How will the Python interpreter react?
Solution:
    SyntaxError: invalid syntax
    ....
"""

