"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: Write a line of code that prompts the user for his or her name and saves the user’s
input in a variable called name.
Solution:

    ....
"""
name = char(input("Nhap ten cua ban: "))
print("Ten cua ban la: ", name)
