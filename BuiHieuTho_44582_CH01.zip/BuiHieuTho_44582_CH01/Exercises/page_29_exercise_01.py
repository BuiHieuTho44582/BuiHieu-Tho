"""
Author: Bui Hieu Tho
Date: 28/08/2021
Program: Describe what happens when the programmer enters the string "Greetings!" in
the Python shell.
Solution:
    It will display the string "Greetings!" in the Python shell
    ....
"""
