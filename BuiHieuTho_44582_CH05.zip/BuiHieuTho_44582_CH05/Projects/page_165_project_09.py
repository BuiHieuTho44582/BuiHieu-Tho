"""
Author: Bui Hieu Tho
Date: 10/10/2021
Problem:Write a loop that accumulates the sum of the numbers in a list named data
Solution:
    ....
"""