"""
Author: Bui Hieu Tho
Date: 10/10/2021
Problem:Give three examples of real-world objects that behave like a dictionary
Solution:
    ....
"""