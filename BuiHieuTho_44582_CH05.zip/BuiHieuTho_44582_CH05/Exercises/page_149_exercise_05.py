"""
Author: Bui Hieu Tho
Date: 10/10/2021

Problem:
           What is the purpose of a main function?
Solution:
     The function main() calls / invokes other functions within it. The execution of the program always starts with
     main() function. The main() function is : - The first function to start a program - Returns int value to the
     environment which called the program - It can be called recursively.
    ...
"""