"""
Author:Bui Hieu Tho
Date: 10/10/2021
Problem:Use the function even to simplify the definition of the function odd presented in
    this section.
Solution:
    ....
"""