"""
Author: Bui Hieu THo
Date: 10/10/2021
Problem:Write a loop that replaces each number in a list named data with its absolute value
Solution:
    ....
"""