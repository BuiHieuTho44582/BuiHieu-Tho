"""
Author: Bui Hieu Tho
Date: 10/10/2021

Problem:
            Define a function named even. This function expects a number as an argument and
returns True if the number is divisible by 2, or it returns False otherwise. (Hint: A
number is evenly divisible by 2 if the remainder is 0.)
Solution:
    Pass the number to the function even
    Check whether the number is divisible by 2 or not
    If it is divisible by 2 True is returned otherwise False is returned
    ...
"""