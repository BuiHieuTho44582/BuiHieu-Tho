"""
Author: Bui Hieu Tho
Date: 10/10/2021

Problem:
            Explain the difference between structural equivalence and object identity
Solution:
    The Object Identity refers to when we create alias to one variable and wanted check whether they both refers to
    the same object or not. That means the two different variables referring to same object.
    ...
"""