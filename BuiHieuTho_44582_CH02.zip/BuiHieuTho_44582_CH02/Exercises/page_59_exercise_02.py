"""
Author: Bui Hieu Tho
Date: 03/09/2021
Program: The math module includes a pow function that raises a number to a given power.
The first argument is the number, and the second argument is the exponent. Write
a code segment that imports this function and calls it to print the values 8^2
and 5^4.
Solution:

  ....
"""
argument1=2
argument2=4
number1=5
number2=8
print("So thu nhat la: ", number2**argument1)
print("So thu hai la: ", number1**argument2)
