"""
Author: Bui Hieu Tho
Date: 03/09/2021
Program: List two of the purposes of program documentation.
Solution:
    1.Docstrings
    2.Testing
  ....
"""
