"""
Author: Bui Hieu Tho
Date: 03/09/2021
Program: Write the values of the following floating-point numbers in Python’s scientific notation:
a. 355.76
b. 0.007832
c. 4.3212
Solution:
    a. 355.76 = 3.5576e2
    b. 0.007832= 7.832e-3
    c. 4.3212 = 4.3212e0
  ....
"""

