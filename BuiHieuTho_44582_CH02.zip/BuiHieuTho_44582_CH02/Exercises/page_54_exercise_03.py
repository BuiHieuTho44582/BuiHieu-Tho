"""
Author: Bui Hieu Tho
Date: 03/09/2021
Program: How does a Python programmer round a float value to the nearest int value?
Solution: A Python programmer take the first number before comma to round a float value to the nearest int value
  ....
"""
