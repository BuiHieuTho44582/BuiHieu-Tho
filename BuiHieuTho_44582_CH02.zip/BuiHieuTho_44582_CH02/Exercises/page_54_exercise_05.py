"""
Author:Bui Hieu Tho
Date: 03/09/2021
Program: Assume that the variable x has the value 55. Use an assignment statement to increment the value of x by 1
Solution:
    x=55
    print("The sum is: ", x+1)
    #The sum is 56
  ....
"""
