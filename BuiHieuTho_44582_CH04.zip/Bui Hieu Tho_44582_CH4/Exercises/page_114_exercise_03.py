"""
Author: Bui Hieu Tho
Date: 24/09/2021

Problem:Translate each of the following numbers to binary numbers:
a. 478
b. 1278
c. 648

Solution:
    1001118
    1010111
    110100
    ....
"""