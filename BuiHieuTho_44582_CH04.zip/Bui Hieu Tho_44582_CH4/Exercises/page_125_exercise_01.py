"""
Author: Bui Hieu Tho
Date: 24/09/2021

Problem: Write a code segment that opens a file named myfile.txt for input and prints the
number of lines in the file

Solution:
    ....
"""
name = open("myfile.txt",'r')
for line in f:
 print(line)